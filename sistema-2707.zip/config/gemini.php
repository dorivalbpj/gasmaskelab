<?php
// config/gemini.php
// Esse arquivo guarda a chave e NUNCA vai pro GitHub
define('GEMINI_API_KEY', 'AIzaSyDf-lBr0NweQr6Z1WWw8r0vKp5YHsmtySg');
?>